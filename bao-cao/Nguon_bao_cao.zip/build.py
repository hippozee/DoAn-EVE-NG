from pathlib import Path
import re,csv,hashlib,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from datetime import datetime,timedelta
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
W=Path('/workspace/work/report'); O=Path('/workspace/output'); R=Path('/workspace/DoAn-EVE-NG')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
def box(ax,x,y,text,w=2.8,h=.9):
 ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=.08',fc='#edf3f8',ec='#38536c',lw=1.3));ax.text(x,y,text,ha='center',va='center',fontsize=10)
def line(ax,a,b,text='',dashed=False):
 ax.plot([a[0],b[0]],[a[1],b[1]],'--' if dashed else '-',color='#46687b',lw=1.6);ax.text((a[0]+b[0])/2,(a[1]+b[1])/2+.15,text,ha='center',fontsize=9,bbox={'facecolor':'white','edgecolor':'none','pad':1})
fig,ax=plt.subplots(figsize=(10,6.2));ax.set(xlim=(0,12),ylim=(0,8));ax.axis('off')
line(ax,(6,5.8),(2.3,3.2),'10.255.1.0/30; cost 10');line(ax,(6,5.8),(9.7,3.2),'10.255.2.0/30; cost 10');line(ax,(2.3,3.2),(9.7,3.2),'wg0: 10.200.12.0/30; cost 5',True)
line(ax,(2.3,2.6),(9.7,2.6),'Underlay: ens6, 172.16.50.0/24');line(ax,(6,5.8),(6,7),'LAN HQ 10.10.10.0/24')
box(ax,6,5.8,'R-HQ\n10.255.0.1');box(ax,2.3,3.2,'R-BR1\nLAN 10.10.20.0/24');box(ax,9.7,3.2,'R-BR2\nLAN 10.10.30.0/24');box(ax,6,7.2,'SERVER-ZABBIX\n10.10.10.100')
ax.text(6,1.3,'Sơ đồ logic tái dựng từ .unl và snapshot cấu hình.\nNét đứt là tunnel; không phải liên kết vật lý riêng.',ha='center',fontsize=10);fig.tight_layout();fig.savefig(W/'topology.png',dpi=210);plt.close(fig)
fig,ax=plt.subplots(figsize=(10,5));ax.set(xlim=(0,12),ylim=(0,6));ax.axis('off')
for x,txt in [(2,'Router HQ / BR1 / BR2\nPhản hồi ICMP'),(6,'Zabbix\nPing / loss / RTT'),(10,'ai_check.py\nKiểm tra dữ liệu')]:box(ax,x,4.8,txt,3.2)
for a,b in [((3.65,4.8),(4.35,4.8)),((7.65,4.8),(8.35,4.8)),((10,4.3),(10,2)),((8.35,1.5),(7.65,1.5)),((4.35,1.5),(3.65,1.5))]:ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':'#46687b','lw':1.5})
box(ax,10,1.5,'Quy tắc ping/loss\nIsolation Forest RTT',3.2);box(ax,6,1.5,'publish_ai_cards.py\nzabbix_sender',3.2);box(ax,2,1.5,'Zabbix trapper\nDashboard và báo cáo',3.2)
ax.text(6,.3,'Kết quả hợp lệ của cả ba router: 1 báo cáo + 9 item số.',ha='center',fontsize=10);fig.tight_layout();fig.savefig(W/'pipeline.png',dpi=210);plt.close(fig)
rows=list(csv.DictReader(open(R/'evidence/ai/2026-11-10/observations.csv')))
fig,axs=plt.subplots(2,1,figsize=(9,6),sharex=True,gridspec_kw={'height_ratios':[1.2,1]})
for name,col in [('HQ','#326589'),('BR1','#c45138'),('BR2','#4a865b')]:
 rr=[r for r in rows if r['router']==name];t=[datetime.strptime(r['report_time_utc'],'%Y-%m-%dT%H:%M:%S%z')+timedelta(hours=7) for r in rr]
 axs[0].plot(t,[float(r['rtt_ms']) for r in rr],'.-',label=name,color=col)
rr=[r for r in rows if r['router']=='BR1'];axs[1].plot(t,[float(r['decision_score']) for r in rr],'.-',color='#c45138');axs[1].axhline(0,color='gray',ls='--',lw=1)
axs[0].set_ylabel('RTT (ms)');axs[0].legend(ncol=3);axs[1].set_ylabel('Decision score BR1');axs[1].set_xlabel('Giờ Việt Nam, 10/11/2026 — thời điểm xuất báo cáo')
import matplotlib.dates as mdates
axs[1].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
for a in axs:a.grid(alpha=.22)
fig.tight_layout();fig.savefig(W/'t10.png',dpi=220);plt.close(fig)
rr=list(csv.DictReader(open(R/'evidence/ai/2026-11-10/T12_states_transcribed.csv')))
print('T12 fields',rr[0].keys())
# Values below are the ten journal observations transcribed in the T12 source document.
times=['16:50:19','16:51:39','16:52:44','16:53:59','16:55:19','16:56:25','16:57:39','16:58:45','16:59:59','17:01:19'];states=[0,0,3,3,3,3,0,0,0,0]
fig,ax=plt.subplots(figsize=(9,3.5));tt=[datetime.strptime(t,'%H:%M:%S') for t in times];ax.plot(tt,states,'o',color='#38536c');ax.plot(tt,states,drawstyle='steps-post',color='#38536c',alpha=.7)
ax.set_yticks([0,3],['0 — Bình thường','3 — Mất phản hồi ICMP']);ax.set_ylim(-.4,3.5);ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'));ax.set_xlabel('Giờ Việt Nam, 10/11/2026 — thời điểm xuất báo cáo');ax.grid(alpha=.2);fig.tight_layout();fig.savefig(W/'t12.png',dpi=220);plt.close(fig)
TITLE='THIẾT KẾ HỆ THỐNG MẠNG WAN ĐA CHI NHÁNH TÍCH HỢP GIÁM SÁT VÀ PHÁT HIỆN BẤT THƯỜNG BẰNG AI TRÊN NỀN TẢNG EVE-NG'
D=Document()
for s in D.sections:
 s.page_width=Cm(21);s.page_height=Cm(29.7);s.top_margin=Cm(2.5);s.bottom_margin=Cm(2.5);s.left_margin=Cm(3);s.right_margin=Cm(2);s.footer_distance=Cm(.5)
for name in ['Normal','Body Text','Caption','Heading 1','Heading 2','Heading 3','Heading 4','TOC 1','TOC 2','TOC 3']:
 try: st=D.styles[name]
 except KeyError: st=D.styles.add_style(name,1)
 st.font.name='Times New Roman';st.font.size=Pt(13);st.font.color.rgb=RGBColor(0,0,0);st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Times New Roman')
 pf=st.paragraph_format;pf.first_line_indent=Cm(0);pf.space_before=Pt(10);pf.space_after=Pt(0);pf.line_spacing=1.5
st=D.styles['Normal'];st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
for lev in range(1,5):
 st=D.styles[f'Heading {lev}'];st.font.size=Pt(14 if lev==1 else 13);st.font.bold=lev<4;st.font.italic=lev>2;pf=st.paragraph_format;pf.space_before=Pt(24 if lev==1 else 6);pf.space_after=Pt(24 if lev==1 else 12);pf.line_spacing=1;pf.keep_with_next=True;pf.alignment=WD_ALIGN_PARAGRAPH.LEFT
st=D.styles['Caption'];st.font.size=Pt(12);st.font.italic=True;pf=st.paragraph_format;pf.space_before=Pt(6);pf.space_after=Pt(6);pf.line_spacing=1;pf.alignment=WD_ALIGN_PARAGRAPH.CENTER
settings=D.settings.element;u=OxmlElement('w:updateFields');u.set(qn('w:val'),'true');settings.append(u)
mirror=OxmlElement('w:mirrorMargins');settings.append(mirror)
def field(p,code,result=''):
 for typ,txt in [('begin',None),('instr',code),('separate',None),('result',result),('end',None)]:
  r=OxmlElement('w:r')
  if typ=='instr':e=OxmlElement('w:instrText');e.set(qn('xml:space'),'preserve');e.text=' '+txt+' '
  elif typ=='result':e=OxmlElement('w:t');e.text=txt
  else:e=OxmlElement('w:fldChar');e.set(qn('w:fldCharType'),typ)
  r.append(e);p._p.append(r)
def center(txt,size=14,bold=False,space=10):
 p=D.add_paragraph();p.alignment=1;p.paragraph_format.space_before=Pt(space);p.paragraph_format.line_spacing=1.2;r=p.add_run(txt);r.font.size=Pt(size);r.bold=bold;return p
def unnumbered(txt):
 p=D.add_paragraph();p.paragraph_format.space_after=Pt(20);p.alignment=1;r=p.add_run(txt);r.bold=True;r.font.size=Pt(14);return p
def section(fmt):
 s=D.add_section(WD_SECTION_START.NEW_PAGE);s.footer.is_linked_to_previous=False
 pg=OxmlElement('w:pgNumType');pg.set(qn('w:fmt'),fmt);pg.set(qn('w:start'),'1');s._sectPr.append(pg)
 p=s.footer.paragraphs[0];p.alignment=1;field(p,'PAGE','1' if fmt=='decimal' else 'i');return s
for inside in [False,True]:
 center('BỘ GIÁO DỤC VÀ ĐÀO TẠO     BỘ NÔNG NGHIỆP VÀ MT',11)
 center('TRƯỜNG ĐẠI HỌC THỦY LỢI',14,True)
 center('[HỌ VÀ TÊN SINH VIÊN]',14,True,65)
 center(TITLE,16,True,45)
 center('ĐỒ ÁN TỐT NGHIỆP',14,True,38)
 if inside:
  center('Ngành: [ĐIỀN NGÀNH]     Mã số: [ĐIỀN MÃ NGÀNH]',13,False,20)
  center('NGƯỜI HƯỚNG DẪN: [XÁC NHẬN HỌ TÊN, HỌC HÀM/HỌC VỊ]',13,False,25)
 center('HÀ NỘI, NĂM 2026',14,False,70 if not inside else 30)
 D.add_page_break()
unnumbered('NHIỆM VỤ ĐỒ ÁN TỐT NGHIỆP')
for s in ['Sinh viên: [HỌ TÊN]    Mã sinh viên: [MÃ SINH VIÊN]','Lớp: [LỚP]    Ngành: [NGÀNH]    Khoa: [KHOA]','Tên đề tài: '+TITLE.capitalize(), '1. Nhiệm vụ: Xây dựng mô hình HQ–BR1–BR2 trên EVE-NG; triển khai OSPF, kết nối WireGuard, giám sát Zabbix và thành phần phân tích RTT bằng Isolation Forest.','2. Nội dung: Khảo sát; thiết kế topology và địa chỉ; triển khai; kiểm thử chức năng; đánh giá kết quả và giới hạn theo minh chứng thực tế.','3. Sản phẩm: Topology, cấu hình, mã nguồn, nhật ký thực nghiệm và báo cáo thuyết minh.','Ngày giao nhiệm vụ: [NGÀY/THÁNG/NĂM]','Ngày hoàn thành: [NGÀY/THÁNG/NĂM]','Giảng viên hướng dẫn: [XÁC NHẬN]','Tờ nhiệm vụ này là dự thảo, cần thay bằng bản được bộ môn/khoa phê duyệt trước khi nộp.']:D.add_paragraph(s)
section('lowerRoman');unnumbered('LỜI CAM ĐOAN')
D.add_paragraph('Tôi cam đoan đã kiểm tra nội dung, nguồn trích dẫn và minh chứng được sử dụng trong đồ án. Các kết quả được trình bày theo phạm vi thực nghiệm đã ghi nhận; những nội dung chưa đo hoặc chưa đủ căn cứ được nêu rõ. Tôi chịu trách nhiệm về bản báo cáo sau khi rà soát, chỉnh sửa và xác nhận trước khi nộp.')
D.add_paragraph('Nội dung lời cam đoan là dự thảo để sinh viên kiểm tra và xác nhận.');center('Hà Nội, ngày … tháng … năm 2026\nSinh viên thực hiện\n(Ký và ghi rõ họ tên)',13,False,30)
D.add_page_break();unnumbered('LỜI CẢM ƠN')
D.add_paragraph('Em xin cảm ơn giảng viên hướng dẫn cùng các thầy cô đã hỗ trợ kiến thức và góp ý trong quá trình thực hiện đồ án. Em cũng xin cảm ơn gia đình và những người đã hỗ trợ điều kiện học tập, thực hành. Các ý kiến góp ý là cơ sở để em tiếp tục hoàn thiện thiết kế, phương pháp kiểm thử và cách trình bày kết quả.')
D.add_paragraph('[Sinh viên chỉnh sửa lời cảm ơn theo quá trình thực hiện và người hỗ trợ thực tế.]')
D.add_page_break();unnumbered('TÓM TẮT ĐỒ ÁN')
D.add_paragraph('Đồ án thiết kế mô hình mạng trụ sở HQ và hai chi nhánh BR1, BR2 trên EVE-NG, sử dụng Debian/FRRouting để định tuyến OSPF và giao diện WireGuard để tổ chức kết nối logic giữa các chi nhánh. Zabbix thu thập trạng thái ICMP, mất gói và thời gian khứ hồi của ba router. Thành phần Python kiểm tra chất lượng đầu vào, áp dụng quy tắc cho mất phản hồi/mất gói và thử nghiệm Isolation Forest một chiều RTT. Kết quả được gửi về Zabbix bằng zabbix_sender và hiển thị trên dashboard.')
D.add_paragraph('Minh chứng đến ngày 10/11/2026 ghi nhận một lần tăng RTT BR1 từ 1,197 lên 107,667 ms làm mô hình đổi sang nhãn nghi ngờ, sau đó về bình thường khi RTT trở lại 1,175 ms. Phép thử mất phản hồi ICMP cho chuỗi trạng thái 0→3→0; chương trình cũng có chạy/gửi sau một lần reboot máy chủ. Các kết quả xác nhận chức năng trong phạm vi lab; chưa có đánh giá precision, recall, F1, độ trễ phát hiện hoặc thời gian hội tụ OSPF.')
D.add_paragraph('Từ khóa: EVE-NG, FRRouting, OSPF, WireGuard, Zabbix, Isolation Forest, RTT.')
# Word fields include readable cached entries; Word fills page references on update.
source=(W/'report.md').read_text();heads=[x for x in source.splitlines() if x.startswith(('# ','## '))]
for title,code,items in [('MỤC LỤC','TOC \\o "1-3" \\h \\z \\u',[re.sub(r'^#+ ','',h) for h in heads]),('DANH MỤC HÌNH ẢNH','TOC \\h \\z \\c "Hình"',[x.split(' | ',1)[1] for x in source.splitlines() if x.startswith('@figure')]),('DANH MỤC BẢNG BIỂU','TOC \\h \\z \\c "Bảng"',[x[7:] for x in source.splitlines() if x.startswith('@table')])]:
 D.add_page_break();unnumbered(title)
 p=D.add_paragraph();field(p,code,'\n'.join(items))
 D.add_paragraph('Cập nhật trường trong Word (Ctrl+A, F9) để tạo số trang và liên kết tự động.').runs[0].italic=True
D.add_page_break();unnumbered('DANH MỤC TỪ VIẾT TẮT')
abbr=[('AI','Artificial Intelligence — Trí tuệ nhân tạo'),('API','Application Programming Interface — Giao diện lập trình ứng dụng'),('CPU','Central Processing Unit — Bộ xử lý trung tâm'),('FIB','Forwarding Information Base — Bảng chuyển tiếp'),('FRR','FRRouting — Bộ phần mềm định tuyến'),('HQ','Headquarters — Trụ sở chính'),('ICMP','Internet Control Message Protocol'),('LAN','Local Area Network — Mạng cục bộ'),('ML','Machine Learning — Học máy'),('OSPF','Open Shortest Path First'),('QoS','Quality of Service — Chất lượng dịch vụ'),('RAM','Random Access Memory — Bộ nhớ truy cập ngẫu nhiên'),('RTT','Round-Trip Time — Thời gian khứ hồi'),('SLA','Service Level Agreement — Thỏa thuận mức dịch vụ'),('SNMP','Simple Network Management Protocol'),('UTC','Coordinated Universal Time'),('VM','Virtual Machine — Máy ảo'),('WAN','Wide Area Network — Mạng diện rộng')]
t=D.add_table(rows=0, cols=2);t.style='Table Grid'
for a,b in abbr:
 c=t.add_row().cells;c[0].text=a;c[1].text=b
section('decimal')
def caption(txt):
 p=D.add_paragraph(style='Caption');m=re.match(r'(Hình|Bảng) ([A-Z0-9]+)\.(\d+)\. (.*)',txt)
 if not m:p.add_run(txt);return
 label,ch,num,tail=m.groups();p.add_run(f'{label} {ch}.');field(p,f'SEQ {label} \\r {num} \\* ARABIC',num);p.add_run('. '+tail)
 if label=='Bảng':p.paragraph_format.keep_with_next=True
lines=source.splitlines();i=0;first=True
while i<len(lines):
 s=lines[i]
 if not s.strip():i+=1;continue
 if s.startswith('# '):
  if not first:D.add_page_break()
  first=False;D.add_paragraph(s[2:],style='Heading 1')
 elif s.startswith('### '):D.add_paragraph(s[4:],style='Heading 3')
 elif s.startswith('## '):D.add_paragraph(s[3:],style='Heading 2')
 elif s.startswith('@figure '):
  filename,cap=s[8:].split(' | ',1);p=D.add_paragraph();p.alignment=1;p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(W/filename),width=Cm(15.7));caption(cap)
 elif s.startswith('@table '):
  caption(s[7:]);i+=1;data=[]
  while i<len(lines) and lines[i].strip():data.append([v.strip() for v in lines[i].split(' | ')]);i+=1
  tab=D.add_table(rows=0,cols=len(data[0]));tab.style='Table Grid';tab.autofit=True
  for idx,row in enumerate(data):
   cells=tab.add_row().cells
   for c,txt in zip(cells,row):
    c.text=txt
    for p in c.paragraphs:
     p.paragraph_format.space_before=Pt(3);p.paragraph_format.space_after=Pt(3);p.paragraph_format.line_spacing=1.1
     for r in p.runs:r.font.size=Pt(10);r.bold=idx==0
   trpr=tab.rows[-1]._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
   if idx==0:
    trpr.append(OxmlElement('w:tblHeader'))
    for c in cells:
     sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E8EEF3');c._tc.get_or_add_tcPr().append(sh)
  continue
 elif s.startswith('```'):
  i+=1;code=[]
  while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
  for line_ in code:
   p=D.add_paragraph();p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=1;p.paragraph_format.keep_with_next=True
   r=p.add_run(line_);r.font.name='Times New Roman';r.font.size=Pt(10)
 else:D.add_paragraph(s)
 i+=1
D.core_properties.title=TITLE.capitalize();D.core_properties.subject='Báo cáo đồ án theo hồ sơ DoAn-EVE-NG, mốc 10/11/2026';D.core_properties.author='[Họ tên sinh viên]'
D.save(O/'Bao_cao_DATN_EVE_NG.docx')
# Portable, editable source with conventional Markdown figures/tables.
md=[];i=0
while i<len(lines):
 s=lines[i]
 if s.startswith('@figure '):
  fn,cap=s[8:].split(' | ',1);md.extend([f'![{cap}]({fn}){{width=95%}}',''])
 elif s.startswith('@table '):
  md.extend(['',s[7:],'']);i+=1;data=[]
  while i<len(lines) and lines[i].strip():data.append(lines[i]);i+=1
  md.extend(['| '+data[0]+' |','| '+' | '.join(['---']*len(data[0].split(' | ')))+' |']+['| '+r+' |' for r in data[1:]]+['']);continue
 else:
  if s.startswith('# '):md.extend(['\\clearpage',''])
  md.append(s)
 i+=1
(W/'body_pdf.md').write_text('\n'.join(md))
(O/'Bao_cao_DATN_nguon.md').write_text(source)
print('DOCX created', (O/'Bao_cao_DATN_EVE_NG.docx').stat().st_size)
