# CHƯƠNG 1. TỔNG QUAN ĐỀ TÀI VÀ YÊU CẦU HỆ THỐNG

## 1.1. Bối cảnh và lý do lựa chọn đề tài

Mạng của một tổ chức có nhiều cơ sở phải đáp ứng đồng thời nhu cầu trao đổi dữ liệu, quản trị tập trung và theo dõi chất lượng kết nối. Khi số lượng chi nhánh tăng, việc chỉ kiểm tra thiết bị có hoạt động hay không chưa đủ phản ánh trải nghiệm sử dụng. Một router vẫn có thể trả lời ping trong khi thời gian khứ hồi tăng mạnh, làm ảnh hưởng đến ứng dụng tương tác. Vì vậy, thiết kế đường đi và giám sát chất lượng cần được xem xét trong cùng một hệ thống.

Đề tài lựa chọn một mô hình gồm trụ sở chính HQ và hai chi nhánh BR1, BR2. Mạng được xây dựng trên EVE-NG, các router sử dụng Debian và FRRouting để thực hiện định tuyến OSPF. Hai chi nhánh có kết nối logic qua WireGuard, bên cạnh các đường tới HQ. Máy chủ Zabbix đặt tại mạng HQ thu thập trạng thái ICMP, tỷ lệ mất gói và độ trễ. Chương trình Python sử dụng lịch sử RTT để thử nghiệm phát hiện mẫu khác thường bằng Isolation Forest.

Giá trị của mô hình nằm ở khả năng theo dõi đầy đủ chuỗi từ cấu hình mạng đến dữ liệu quan sát và kết quả phân tích. Người quản trị có thể kiểm tra tuyến, đối chiếu mẫu giám sát với nhãn mô hình và xem kết quả trên một dashboard. Cách tổ chức này cũng giúp phân biệt lỗi kết nối, suy giảm chất lượng và lỗi của chính hệ thống thu thập dữ liệu.

## 1.2. Mục tiêu của đồ án

Mục tiêu tổng quát là thiết kế, triển khai và kiểm tra chức năng mô hình mạng nhiều cơ sở, tích hợp giám sát tập trung và thử nghiệm phát hiện độ trễ bất thường. Báo cáo được xây dựng từ mã nguồn, topology, bản xuất cấu hình và hồ sơ thực nghiệm trong repository hippozee/DoAn-EVE-NG [1]. Mốc kết quả thực nghiệm được sử dụng là ngày 10/11/2026.

Các mục tiêu cụ thể gồm: thiết lập các mạng LAN và liên kết giữa ba cơ sở; sử dụng OSPF để trao đổi tuyến; tổ chức đường BR1–BR2 qua giao diện wg0; đưa dữ liệu ICMP của ba router vào Zabbix; xây dựng chương trình kiểm tra chất lượng dữ liệu trước khi phân tích; tích hợp kết quả vào dashboard và kiểm tra phản ứng khi gây trễ hoặc mất phản hồi ICMP.

Đối với thành phần học máy, mục tiêu đã triển khai là phân loại mẫu RTT hiện tại theo lịch sử gần đây của từng router. Đánh giá precision, recall, F1 và so sánh với phương pháp ngưỡng là mục tiêu nghiên cứu tiếp theo, chưa có dữ liệu đầy đủ để kết luận trong phiên bản này.

## 1.3. Phạm vi thực hiện

Mô hình gồm tám node trong tệp EVE-NG: ba router, ba máy đầu cuối VPC và hai máy chủ SERVER-HQ, SERVER-ZABBIX. Phần router dùng Linux/FRRouting; các cấu hình Cisco và phương án hai đường WAN riêng cho từng chi nhánh trong đề cương cũ không phản ánh topology hiện hành. Báo cáo giữ định hướng mạng đa cơ sở nhưng mô tả đúng cấu hình đã lưu.

Phạm vi giám sát phục vụ chương trình phân tích là ba nhóm item ICMP. Mặc dù tài liệu ban đầu đề cập SNMP và lưu lượng, chưa có bộ dữ liệu được xác nhận để sử dụng các đại lượng đó làm đặc trưng. Phạm vi học máy hiện tại chỉ gồm một đặc trưng RTT. Mất kết nối và mất gói được xử lý bằng quy tắc riêng.

Các kết luận của báo cáo áp dụng cho môi trường mô phỏng và bộ minh chứng đã lưu. Chưa có phép đo để cam kết SLA, thông lượng doanh nghiệp, thời gian hội tụ OSPF hoặc mức tiết kiệm băng thông. Mã nguồn được đọc từ bản sao trong repository; báo cáo không thay thế một đợt nghiệm thu trực tiếp các máy ảo đang vận hành.

## 1.4. Yêu cầu chức năng và tiêu chí kiểm tra

@table Bảng 1.1. Yêu cầu và phương pháp xác minh
Yêu cầu | Thành phần thực hiện | Căn cứ/kiểm thử
Trao đổi tuyến giữa ba cơ sở | FRRouting, OSPF area 0 | T01; neighbor Full và bảng tuyến
Ưu tiên đường giữa hai chi nhánh | wg0, OSPF cost 5 | T03; snapshot tuyến, cần đo lưu lượng
Giám sát trạng thái và chất lượng | Zabbix ICMP | T02; lastvalue và lastclock
Phát hiện RTT khác thường | Isolation Forest theo router | T09, T10
Phân biệt mất phản hồi ICMP | Quy tắc ping bằng 0 | T12
Hiển thị kết quả tập trung | Sender, trapper, dashboard | T14
Tự chạy sau khởi động máy chủ | systemd service và timer | T15

Ngoài các yêu cầu chức năng, hệ thống cần có khả năng tái lập cấu hình, xác định nguồn dữ liệu và khôi phục sau thử nghiệm. Những thay đổi gây lỗi phải có phương án gỡ bỏ. Kết quả phân tích phải thể hiện trạng thái chờ hoặc lỗi khi chưa đủ dữ liệu, tránh hiển thị bình thường chỉ vì chương trình thiếu đầu vào.

## 1.5. Phương pháp thực hiện và tổ chức báo cáo

Quá trình thực hiện kết hợp nghiên cứu cơ sở kỹ thuật, đọc cấu hình thực tế, đối chiếu mã nguồn và phân tích nhật ký. Minh chứng được phân thành ba nhóm: tệp gốc như topology, mã và log; bảng trích xuất từ log; tài liệu ghi lại ảnh thao tác. Mỗi loại có mức độ chi tiết khác nhau và được ghi rõ trong phần thực nghiệm.

Báo cáo gồm sáu chương. Chương 1 giới thiệu bài toán và yêu cầu. Chương 2 trình bày các công nghệ nền tảng. Chương 3 mô tả thiết kế. Chương 4 trình bày triển khai mạng và giám sát. Chương 5 phân tích thành phần phát hiện bất thường. Chương 6 tổng hợp kiểm thử, đánh giá và hướng phát triển. Phụ lục cung cấp ánh xạ dữ liệu, cấu hình tiêu biểu và danh mục minh chứng.

# CHƯƠNG 2. CƠ SỞ LÝ THUYẾT

## 2.1. Mô phỏng mạng bằng EVE-NG

EVE-NG cung cấp môi trường xây dựng topology và kết nối các thiết bị ảo, giúp thực hành cấu hình nhiều node trên cùng một hạ tầng [2]. Trong đề tài, EVE-NG đóng vai trò tổ chức liên kết mạng và vòng đời của các máy ảo. Chức năng định tuyến do hệ điều hành và FRRouting bên trong từng router thực hiện.

Một liên kết trên sơ đồ EVE-NG cần được đối chiếu với giao diện trong hệ điều hành khách. Tên e0, e1, e3 trong tệp lab không đồng nhất với ens3, ens4, ens6 trên Linux. Việc xác minh dựa trên địa chỉ MAC, địa chỉ IP và kết nối thực tế giúp tránh áp dụng cấu hình nhầm cổng, đặc biệt khi thử nghiệm gây gián đoạn.

Tài nguyên máy chủ vật lý ảnh hưởng trực tiếp đến dữ liệu đo. Khi nhiều máy ảo cạnh tranh CPU hoặc bộ nhớ, RTT có thể thay đổi dù không có lỗi WAN. Vì vậy, diễn giải kết quả bất thường cần xét điều kiện môi trường mô phỏng; một mẫu RTT cao chưa đủ xác định nguyên nhân ở hạ tầng truyền dẫn.

## 2.2. Định tuyến OSPF

Open Shortest Path First là giao thức định tuyến trạng thái liên kết. Các router trao đổi thông tin về topology trong phạm vi area, xây dựng cơ sở dữ liệu trạng thái liên kết và tính đường đi theo tổng chi phí [3]. Router-ID xác định duy nhất một router trong quá trình trao đổi thông tin.

Trạng thái neighbor Full thể hiện hai router đã hoàn thành đồng bộ cần thiết cho quan hệ kề tương ứng. Tuy nhiên, neighbor Full không tự chứng minh ứng dụng giữa hai LAN hoạt động; vẫn cần kiểm tra bảng tuyến, khả năng chuyển tiếp và chính sách lọc. Trong mô hình này, các LAN được cấu hình passive để quảng bá mạng mà không hình thành quan hệ OSPF với máy đầu cuối.

Chi phí OSPF cho phép điều khiển lựa chọn đường. Các liên kết từ HQ tới chi nhánh có cost 10; giao diện wg0 giữa hai chi nhánh có cost 5. Khi đích là LAN chi nhánh còn lại, snapshot FRR ghi nhận đường qua wg0 có metric 6, bao gồm chi phí giao diện tunnel và chi phí mạng LAN đích. Con số metric 20 hiển thị trong bảng tuyến Linux là một trường khác, không được thay thế cho tổng cost OSPF.

Các tham số hello và dead ảnh hưởng việc nhận biết neighbor. Trên wg0, hello là 2 giây và dead là 8 giây theo bản xuất cấu hình. Không thể từ dead interval suy ra chính xác thời gian gián đoạn của ứng dụng, vì còn phụ thuộc phát hiện lỗi, tính lại tuyến, cài đặt FIB và nhịp phép đo.

## 2.3. Router Linux và FRRouting

FRRouting là bộ phần mềm định tuyến hỗ trợ nhiều giao thức, trong đó có OSPF, và cung cấp giao diện vtysh để cấu hình, kiểm tra trạng thái [4]. Linux đảm nhiệm giao diện mạng và chuyển tiếp gói; FRR học tuyến và trao đổi với hệ thống định tuyến của kernel.

Cách phân tách này giúp quan sát hai lớp trạng thái. Lệnh ip route cho thấy tuyến mà kernel sử dụng, còn show ip route và show ip ospf neighbor trong vtysh phản ánh góc nhìn của FRR. Khi kết quả không thống nhất, cần kiểm tra việc cài đặt tuyến, địa chỉ nguồn và chính sách định tuyến thay vì chỉ đọc một màn hình.

Bản cấu hình trong repository ghi FRR 8.4.4, còn image router được đặt tên linux-debian12-frr. Đây là căn cứ lựa chọn nền tảng triển khai trong báo cáo. Tệp topology mô tả tài nguyên cấp cho node, nhưng không chứng minh cấu hình CPU/RAM thực tế của máy chủ vật lý.

## 2.4. WireGuard và phân biệt underlay, overlay

WireGuard xây dựng kết nối mạng riêng ảo dựa trên cặp khóa và cấu hình peer [5]. Trong mô hình, mạng 172.16.50.0/24 trên ens6 là lớp kết nối nền, còn giao diện wg0 sử dụng mạng 10.200.12.0/30 là kết nối logic giữa BR1 và BR2. Định tuyến OSPF chạy trên giao diện logic này.

Việc phân biệt underlay và overlay tránh hiểu nhầm đường tunnel là một dây mạng vật lý độc lập. Underlay phải cho phép các peer trao đổi gói mang tunnel. Bảng tuyến qua wg0 chứng minh kernel đã chọn giao diện logic, nhưng muốn xác nhận trạng thái mã hóa đang hoạt động cần kiểm tra handshake, bộ đếm truyền nhận và thử lưu lượng ở cả hai đầu.

Bộ hồ sơ hiện có chưa chứa cấu hình WireGuard đã che khóa và ảnh handshake mới. Do đó, báo cáo mô tả cấu trúc kết nối và tuyến đã quan sát, đồng thời giữ việc nghiệm thu tunnel là một hạng mục cần bổ sung. Khóa riêng không được đưa vào báo cáo hoặc gói mã nguồn công khai.

## 2.5. Zabbix và giám sát ICMP

Zabbix tổ chức giám sát thông qua host, interface, template, item, trigger và dashboard [6]. Item xác định đại lượng cần thu thập; lịch sử lưu các giá trị theo thời gian; trigger biểu diễn điều kiện cảnh báo; dashboard trình bày kết quả cho người vận hành. Có dữ liệu trên widget chưa đồng nghĩa đã thiết lập thông báo chủ động.

Ba đại lượng đầu vào được sử dụng là icmpping, icmppingloss và icmppingsec. Chúng lần lượt phản ánh khả năng phản hồi ICMP, tỷ lệ mất gói và thời gian khứ hồi. Giá trị RTT từ Zabbix dùng đơn vị giây, trong khi chương trình đổi sang mili giây bằng hệ số 1000 để phân tích và hiển thị.

Phép đo ICMP phản ánh đường đi giữa máy đo và địa chỉ đích. Nếu gói ICMP bị lọc tại máy đo, Zabbix có thể ghi nhận mất phản hồi dù router vẫn hoạt động với các dịch vụ khác. Ngược lại, router trả lời ping không bảo đảm mọi ứng dụng phía sau router đều hoạt động. Giới hạn này cần được duy trì khi đặt tên trạng thái và trình bày kết quả.

API history.get cho phép lấy các mẫu lịch sử theo item, loại dữ liệu và khoảng thời gian [7]. Việc chọn đúng history type và itemid là điều kiện để dữ liệu trả về có ý nghĩa. Itemid là định danh trong từng database, không phải hằng số dùng chung cho mọi hệ thống Zabbix.

## 2.6. Isolation Forest và điểm quyết định

Isolation Forest là phương pháp phát hiện bất thường dựa trên việc cô lập điểm dữ liệu bằng các phép chia ngẫu nhiên. Ý tưởng cơ bản là một số điểm hiếm hoặc khác biệt có thể bị cô lập với ít bước hơn các điểm thuộc vùng dữ liệu phổ biến [8]. Thuật toán phù hợp với thử nghiệm không có nhãn huấn luyện đầy đủ, nhưng vẫn cần nhãn độc lập để đánh giá chất lượng.

Trong scikit-learn, predict trả về +1 cho mẫu được mô hình xem là bình thường và -1 cho mẫu bất thường; decision_function cung cấp điểm quyết định để đối chiếu mức độ khác biệt theo mô hình [9]. Điểm này không phải xác suất xảy ra sự cố và không biểu thị phần trăm chính xác.

Phiên bản đề tài xây dựng một mô hình riêng cho từng router với đầu vào một chiều RTT. Mẫu hiện tại được đánh giá sau khi mô hình học từ các mẫu quá khứ. Cấu hình contamination=auto dùng cơ chế mặc định của thư viện để xác lập ranh giới; không có nghĩa hệ thống đã biết tỷ lệ sự cố thực tế trong mạng.

## 2.7. Nguyên tắc đánh giá

Kiểm thử chức năng trả lời câu hỏi hệ thống có phản ứng theo kịch bản cụ thể hay không. Đánh giá thống kê trả lời câu hỏi hệ thống đúng đến mức nào trên một tập dữ liệu có nhãn. Hai mục đích này cần phân biệt, vì một lần tạo độ trễ lớn và nhận được cảnh báo chưa đại diện cho nhiều dạng bất thường và nhiều điều kiện tải.

Muốn đánh giá định lượng, cần tách dữ liệu huấn luyện, xác thực và kiểm thử theo thời gian; cố định mô hình hoặc quy trình cập nhật; ghi nhãn độc lập và lưu thời điểm gây lỗi. Các số đếm TP, FP, TN, FN là cơ sở tính precision, recall và F1. Khi chưa có nhãn và chưa biết thời điểm phát sinh sự cố, không thể suy ra các chỉ số này hoặc độ trễ phát hiện từ timestamp của báo cáo.

# CHƯƠNG 3. PHÂN TÍCH VÀ THIẾT KẾ HỆ THỐNG

## 3.1. Kiến trúc tổng thể

Hệ thống được chia thành lớp kết nối, lớp giám sát và lớp phân tích. Lớp kết nối gồm ba router và các mạng LAN/WAN. Lớp giám sát sử dụng SERVER-ZABBIX để đo ICMP tới ba địa chỉ router. Lớp phân tích chạy trên cùng máy chủ, truy vấn API nội bộ và gửi kết quả trở lại Zabbix.

@figure topology.png | Hình 3.1. Sơ đồ logic HQ–BR1–BR2 theo cấu hình lưu trong repository

Hình 3.1 biểu diễn hai đường HQ–chi nhánh và kết nối logic WireGuard giữa hai chi nhánh. Đường tunnel được phân biệt với underlay 172.16.50.0/24. SERVER-ZABBIX nối vào LAN HQ; địa chỉ 10.10.10.100 được ghi nhận trong hồ sơ T10 và T12. Ngoài LAN, tệp lab còn nối hai máy chủ tới pnet0/Net-Internet để phục vụ truy cập trong môi trường lab.

## 3.2. Thành phần và tài nguyên cấp phát

@table Bảng 3.1. Các node trong tệp DoAn_HQ_BR1_BR2.unl
Node | Image/loại | vCPU | RAM cấu hình
R-HQ | linux-debian12-frr | 1 | 1024 MB
R-BR1 | linux-debian12-frr | 1 | 1024 MB
R-BR2 | linux-debian12-frr | 1 | 1024 MB
SERVER-HQ | linux-debian12-frr | 2 | 2048 MB
SERVER-ZABBIX | linux-debian12-zabbix | 2 | 2048 MB
VPC, VPC-BR1, VPC-BR2 | VPCS | Không ghi | Không ghi

Tổng RAM cấu hình của năm node QEMU là 7168 MB, chưa gồm VPCS và chi phí vận hành EVE-NG. Đây là tổng hợp từ thuộc tính trong tệp lab, không phải số đo RAM thực sử dụng. Chưa có bản xuất cấu hình máy chủ vật lý để kết luận mức tài nguyên dư hoặc hiệu năng tối đa.

## 3.3. Quy hoạch địa chỉ

@table Bảng 3.2. Địa chỉ các giao diện router theo snapshot
Node | Giao diện | Địa chỉ | Vai trò
HQ | ens3 | 10.10.10.1/24 | LAN HQ
HQ | ens4 | 10.255.1.1/30 | WAN tới BR1
HQ | ens6 | 10.255.2.1/30 | WAN tới BR2
BR1 | ens3 | 10.10.20.1/24 | LAN BR1
BR1 | ens4 | 10.255.1.2/30 | WAN tới HQ
BR1 | ens6 | 172.16.50.1/24 | Underlay tới BR2
BR1 | wg0 | 10.200.12.1/30 | Tunnel tới BR2
BR2 | ens3 | 10.10.30.1/24 | LAN BR2
BR2 | ens4 | 10.255.2.2/30 | WAN tới HQ
BR2 | ens6 | 172.16.50.2/24 | Underlay tới BR1
BR2 | wg0 | 10.200.12.2/30 | Tunnel tới BR1

Mỗi LAN sử dụng một mạng /24 riêng để phân biệt phạm vi cơ sở. Hai đường HQ–chi nhánh dùng /30 nhằm thể hiện kết nối điểm tới điểm. Các địa chỉ máy trạm chưa có bản xuất đầy đủ nên không tự bổ sung vào Bảng 3.2. Khi tái lập, cần xác nhận gateway và địa chỉ đầu cuối trước khi kiểm tra liên LAN.

## 3.4. Thiết kế định tuyến và đường ưu tiên

Ba router hoạt động trong area 0, có Router-ID lần lượt là 10.255.0.1, 10.255.0.2 và 10.255.0.3. Các giao diện LAN được đặt passive. WAN giữa HQ với mỗi chi nhánh sử dụng network type point-to-point và cost 10. Giao diện wg0 sử dụng network type non-broadcast, cost 5 và neighbor khai báo tường minh.

@table Bảng 3.3. Một số tuyến đã ghi nhận trong snapshot FRR
Router | Mạng đích | Next hop/cổng | Metric FRR
HQ | 10.10.20.0/24 | 10.255.1.2, ens4 | [110/11]
HQ | 10.10.30.0/24 | 10.255.2.2, ens6 | [110/11]
BR1 | 10.10.30.0/24 | 10.200.12.2, wg0 | [110/6]
BR2 | 10.10.20.0/24 | 10.200.12.1, wg0 | [110/6]

Bảng 3.3 cho thấy lựa chọn tuyến tại thời điểm xuất cấu hình. Khi đường trực tiếp giữa chi nhánh không khả dụng, topology có khả năng cung cấp đường qua HQ theo cơ chế OSPF, nhưng kết quả chuyển tuyến và thời gian gián đoạn phải được xác nhận bằng T05–T06. Chưa có nhật ký thực nghiệm cho hai phép thử đó.

## 3.5. Thiết kế luồng giám sát và phân tích

@figure pipeline.png | Hình 3.2. Luồng dữ liệu ICMP, phân tích Python và hiển thị Zabbix

Zabbix thu thập ba item cho mỗi router. Chương trình ai_check.py đăng nhập API, đọc giá trị hiện tại và timestamp, kiểm tra chất lượng, sau đó đi vào nhánh quy tắc hoặc nhánh học máy. Publisher tiếp nhận kết quả và gửi một báo cáo văn bản cùng các item số. Dashboard đọc các item này để thể hiện trạng thái của từng cơ sở và đồ thị RTT.

Một vòng xử lý khỏe cho cả ba router tạo 10 giá trị: ai.report và chín giá trị state/RTT/loss. Khi đầu vào lỗi, publisher có thể chỉ gửi state cho router liên quan. Vì vậy, số giá trị gửi phải được kiểm tra theo payload thực tế thay vì luôn yêu cầu con số 10 trong mọi tình huống.

## 3.6. Thiết kế bảo vệ và giới hạn quyền

Vai trò HQ là nơi tập trung quản trị và máy chủ giám sát. OSPF quyết định đường đi, không tự xác lập quyền truy cập giữa các LAN. Muốn kiểm soát chi nhánh truy cập HQ cần có ma trận nguồn, đích, dịch vụ và hành động, sau đó đối chiếu với firewall ruleset và thử nghiệm thực tế.

Tương tự, lựa chọn cost không phải cơ chế QoS. Ưu tiên lưu lượng khi nghẽn cần phân loại, hàng đợi và số đo trước/sau dưới tải cạnh tranh. Bộ hồ sơ hiện chưa đủ để kết luận hiệu quả QoS hoặc chính sách firewall đã đạt yêu cầu. Hai nội dung này được giữ ở trạng thái cần bổ sung thay vì quy thành kết quả của OSPF.

Với thành phần phân tích, thông tin đăng nhập được lưu cục bộ ngoài repository. Hướng triển khai tiếp theo là tài khoản dịch vụ tối thiểu quyền và quyền truy cập tệp phù hợp. Bản service được xuất hiện chạy với User=root; đây là hiện trạng cần cải thiện khi đưa ra ngoài phạm vi lab.

# CHƯƠNG 4. TRIỂN KHAI MẠNG VÀ HỆ THỐNG GIÁM SÁT

## 4.1. Môi trường và phiên bản

@table Bảng 4.1. Thành phần triển khai và căn cứ phiên bản
Thành phần | Phiên bản/đặc điểm | Căn cứ
Router | Debian 12, FRR 8.4.4 | Tên image và bản xuất FRR
Zabbix API/server | 7.0.31 tại mốc quan sát | Hồ sơ ảnh ngày 09/11
Zabbix frontend | 7.0.32 sau cài sender | Hồ sơ ảnh Global view
Python | 3.11 trong môi trường ảo | Đường dẫn thư viện trong hồ sơ
Thư viện phân tích | NumPy, scikit-learn, requests | Mã và ai/requirements.txt

Phiên bản frontend và tiến trình server được ghi riêng vì hồ sơ sau nâng gói chưa xác nhận server đã chạy cùng phiên bản frontend. Các số phiên bản thư viện được lưu trong requirements để tái lập theo bản xuất; chưa có thao tác dựng lại toàn bộ môi trường từ đầu trong quá trình viết báo cáo này.

## 4.2. Cấu hình router và kiểm tra OSPF

Sau khi nối cổng theo topology, địa chỉ IP được đối chiếu bằng ip -br a. Tiếp theo kiểm tra tính nhất quán của subnet, khả năng chuyển tiếp trên Linux và trạng thái FRR. Việc tách bước xác nhận IP với bước chạy giao thức giúp nhận biết lỗi kết nối cơ bản trước khi phân tích lỗi OSPF.

Cấu hình tiêu biểu của HQ đặt ens3 trong area 0 và passive; ens4, ens6 trong area 0 với cost 10, network point-to-point. Router-ID là 10.255.0.1. Bản xuất HQ ghi hai neighbor ở trạng thái Full và có các tuyến tới LAN BR1, BR2 với next hop tương ứng. Cấu hình rút gọn được đưa vào Phụ lục B.

Đối với BR2, ens4 kết nối HQ; wg0 có cost 5, hello 2, dead 8 và neighbor 10.200.12.1. Snapshot ghi neighbor HQ Full/- và neighbor BR1 Full/Backup trên wg0. Từ Backup trong trạng thái này liên quan vai trò OSPF trên mạng non-broadcast, không phải phép đo chứng minh đường truyền dự phòng đã được thử thành công.

Các lệnh kiểm tra được sử dụng gồm ip route, show ip route và show ip ospf neighbor. Khi kiểm tra lưu lượng của máy trạm, cần dùng đúng địa chỉ nguồn hoặc chạy từ máy thuộc LAN tương ứng, vì tuyến phát sinh từ router có thể khác đường của lưu lượng được chuyển tiếp.

## 4.3. Kết nối WireGuard

Hai router chi nhánh có địa chỉ underlay trên ens6 và địa chỉ tunnel trên wg0. Các tuyến tới LAN chi nhánh còn lại được ghi nhận đi qua next hop 10.200.12.1 hoặc 10.200.12.2. Đây là phần cấu hình đã được lưu trong các tệp CHECK.

Bước xác nhận bổ sung cần thực hiện trên lab là xem wg show ở cả hai đầu, xác định handshake còn mới, kiểm tra counters tăng khi truyền thử và đối chiếu cấu hình peer/AllowedIPs đã che khóa. Vì bộ dữ liệu hiện tại thiếu các bản xuất đó, báo cáo chưa nghiệm thu chi tiết tham số bảo mật hoặc tính sẵn sàng của tunnel.

## 4.4. Tổ chức host và item Zabbix

Ba host được giám sát là R-HQ, R-BR1 và R-BR2 với địa chỉ LAN của router. Mỗi host sử dụng ba item ICMP tương ứng ping, loss và RTT. Ánh xạ itemid hiện có được lưu ở Phụ lục A, đúng với database trong hồ sơ ngày 09/11.

Khi kiểm tra dữ liệu, cần xem đồng thời lastvalue, lastclock, status và state. Một giá trị 0 đi kèm lastclock=0 có thể là chưa từng có mẫu, không phải một phép đo mới về trạng thái mất kết nối. Chính vì vậy, chương trình kiểm tra độ mới và trạng thái item trước khi áp dụng quy tắc.

Kết quả được ghi về host kỹ thuật Zabbix server. Tên host này là nơi lưu các item phân tích, không có nghĩa mô hình chỉ đánh giá máy chủ. Các key ai.state[HQ], ai.state[BR1], ai.state[BR2] tương ứng ba router; các key RTT/loss dùng cùng hậu tố.

## 4.5. Gửi kết quả về Zabbix

Bản tích hợp ban đầu sử dụng history.push và gặp lỗi nguồn kết nối không nằm trong Allowed hosts. Đường gửi đã được chuyển sang zabbix_sender, chỉ định nguồn và đích 127.0.0.1 [10]. Cách triển khai hiện tại sử dụng các item trapper trên host Zabbix server.

Publisher tìm chương trình sender, gọi ai_check.py dưới dạng subprocess và thu stdout. Kết quả được ghép với thời điểm xuất báo cáo, sau đó tách theo từng khối router. Payload được gửi theo batch. Chương trình kiểm tra returncode và chuỗi processed đúng số lượng, failed bằng 0 trước khi ghi thông báo thành công.

Log T10 có 12 báo cáo hoàn chỉnh, mỗi batch xác nhận processed: 10; failed: 0. Kết quả này chứng minh đường gửi đã hoạt động cho các batch ghi trong log. Không từ đó suy ra mọi item luôn cập nhật ở những thời điểm không có dữ liệu hoặc nguyên nhân gốc của lỗi history.push đã được xác định.

## 4.6. Dashboard giám sát kết quả

Dashboard AI Network Analysis tổ chức ba thẻ Item value cho trạng thái HQ, BR1, BR2; đồ thị RTT sử dụng ba series; báo cáo chi tiết được hiển thị qua Item history. Việc đổi tên widget không thay đổi item nguồn, do đó mỗi thẻ phải chọn đúng key của router.

Mỗi báo cáo văn bản chứa nhiều dòng nhưng là một bản ghi lịch sử. Thiết lập Show lines bằng 1 nhằm giữ bản ghi mới nhất, không phải cắt báo cáo còn một dòng. Đối với state, value map giúp chuyển mã số sang nhãn đọc được. Thời điểm trên thẻ và khung thời gian của graph cần được đối chiếu để tránh nhầm dữ liệu lịch sử là dữ liệu hiện tại.

Repo có tài liệu mô tả ảnh dashboard ngày 10/11 nhưng chưa chứa các tệp ảnh đó. Báo cáo này dùng sơ đồ tái dựng và đồ thị vẽ từ CSV đã lưu, không trình bày chúng như ảnh chụp giao diện trực tiếp.

## 4.7. Lập lịch và đồng bộ thời gian

Service network-ai-check có kiểu oneshot. Timer đặt OnBootSec=60s và OnUnitInactiveSec=60s, tức lần tiếp theo được lập lịch khoảng 60 giây sau khi lần trước kết thúc. Tổng chu kỳ còn gồm thời gian truy vấn API, fit mô hình và gửi kết quả; không bảo đảm chạy đúng mỗi mốc phút.

Tệp service gốc gọi ai_check.py nhưng drop-in publish.conf xóa ExecStart cũ và thay bằng publish_ai_cards.py, với TimeoutStartSec=180. Khi khôi phục phải giữ cả drop-in; chỉ sao chép service gốc sẽ thiếu bước gửi dashboard. Trạng thái inactive sau một lần oneshot hoàn thành không tự biểu thị lỗi.

Hồ sơ ghi nhận SERVER-ZABBIX từng lệch ngày và đã được chỉnh bằng chrony. Các lệnh chronyc makestep, burst, waitsync và tracking được sử dụng để kiểm tra trạng thái đồng bộ [11]. Sau xử lý, tài liệu ghi Leap status Normal và timestamp đúng ngày 10/11. Chưa có bằng chứng đồng bộ dài hạn cho toàn bộ router hoặc sau mọi lần suspend.

Thời gian của terminal và log gốc dùng UTC; phần trình bày kết quả trong báo cáo dùng giờ Việt Nam UTC+7. Timestamp xuất báo cáo phải được phân biệt với thời điểm lấy mẫu ICMP và thời điểm áp dụng tác động thử nghiệm.

# CHƯƠNG 5. XÂY DỰNG THÀNH PHẦN PHÁT HIỆN BẤT THƯỜNG

## 5.1. Đầu vào và cấu trúc chương trình

Thành phần phân tích có hai nhiệm vụ chính: ai_check.py đọc dữ liệu và đưa ra kết luận; publish_ai_cards.py chuyển kết luận thành dữ liệu Zabbix. Các tệp setup_login.py và setup_ai_cards.py hỗ trợ chuẩn bị thông tin đăng nhập và các item hiển thị. systemd chịu trách nhiệm lập lịch, không thực hiện trực tiếp mô hình học máy.

Trong ai_check.py, biến HOSTS ánh xạ mỗi router tới ba itemid theo thứ tự ping, loss, RTT. Chương trình đăng nhập API nội bộ bằng thông tin trong /opt/network-ai/credentials.json, đặt Bearer token cho phiên requests, truy vấn item.get rồi xử lý lần lượt từng router. Cuối phiên có thao tác logout trong khối finally.

Đối với lỗi riêng một host, chương trình in thông báo để tiếp tục kiểm tra các host khác. Tuy nhiên một số ngoại lệ được bắt và in ra mà không làm tiến trình kết thúc với mã lỗi khác 0. Vì vậy, cần đọc nội dung kết quả; chỉ dựa vào trạng thái service Finished không đủ xác nhận phân tích thành công.

## 5.2. Kiểm soát chất lượng dữ liệu

@table Bảng 5.1. Điều kiện kiểm tra dữ liệu trước khi đánh giá RTT
Điều kiện | Cách xử lý trong mã | Ý nghĩa
Thiếu một item trong nhóm | In THIEU ITEM | Không đủ đầu vào
Item state/status khác 0 | In DU LIEU CU/LOI | Không sử dụng kết luận mạng
lastclock bằng 0 | In DU LIEU CU/LOI | Chưa có mẫu
Độ lệch thời gian tuyệt đối trên 180 giây | In DU LIEU CU/LOI | Dữ liệu không phù hợp hiện tại
Ping bằng 0, dữ liệu hợp lệ | Quy tắc mất kết nối | Không gọi Isolation Forest
Loss lớn hơn 0, ping khác 0 | Quy tắc mất gói | Không gọi Isolation Forest

Kiểm tra độ lệch tuyệt đối cũng loại trường hợp timestamp quá xa trong tương lai, có thể xuất hiện khi đồng hồ không thống nhất. Ba item được kiểm tra độc lập về độ mới nhưng mã chưa yêu cầu chúng có cùng timestamp. Khi phân tích chuỗi sự cố ngắn, chênh thời điểm cập nhật giữa ping, loss và RTT là một giới hạn cần lưu ý.

## 5.3. Chuẩn bị lịch sử RTT

Chương trình gọi history.get với history=0, giới hạn tối đa 500 mẫu trong 24 giờ. time_till được đặt bằng lastclock của RTT hiện tại trừ 1, nhằm tránh đưa chính mẫu đang đánh giá vào dữ liệu học của lần chạy đó. Chỉ các giá trị lớn hơn 0 được giữ lại và chuyển từ giây sang mili giây.

Hai điều kiện tối thiểu là có ít nhất 30 mẫu và ít nhất 5 giá trị RTT phân biệt. Nếu không đáp ứng, chương trình ghi trạng thái chờ dữ liệu hoặc chưa đánh giá. Các con số này là điều kiện khởi động do chương trình lựa chọn, không phải kết quả nghiên cứu chứng minh kích thước mẫu tối ưu.

Lịch sử RTT chưa được ghép theo timestamp với lịch sử ping/loss để loại toàn bộ giai đoạn suy giảm. Vì vậy, tập học có thể chứa các mẫu từ thời điểm mạng không khỏe. Khi bất thường kéo dài, cơ chế lấy cửa sổ gần nhất và fit lại có thể dần đưa các mẫu đó thành hành vi phổ biến trong dữ liệu học.

## 5.4. Huấn luyện và suy luận

@table Bảng 5.2. Tham số mô hình Isolation Forest trong bản xuất
Tham số | Giá trị | Vai trò
Số chiều đầu vào | 1, RTT theo ms | Một mô hình cho từng router
n_estimators | 100 | Số cây
contamination | auto | Cơ chế ngưỡng của thư viện
random_state | 42 | Cố định trạng thái ngẫu nhiên
n_jobs | 1 | Một luồng tác vụ theo cấu hình
Số mẫu lịch sử tối đa | 500 | Giới hạn truy vấn mỗi vòng

Dữ liệu được đưa về mảng có dạng số mẫu nhân một đặc trưng. Mô hình fit lại trong mỗi lần xử lý router, sau đó predict và decision_function đánh giá một mẫu RTT hiện tại. Nhãn -1 tạo thông điệp nghi ngờ bất thường; nhãn +1 tạo thông điệp RTT bình thường.

Cơ chế hiện tại thuận tiện cho demo vì không cần quản lý tệp mô hình, nhưng khó so sánh điểm qua nhiều thời điểm khi tập học thay đổi. Để đánh giá có kiểm soát, nên lưu baseline khỏe, phiên bản mô hình và thời điểm huấn luyện, sau đó khóa chúng trong giai đoạn kiểm thử độc lập.

## 5.5. Quy tắc và mã trạng thái đầu ra

@table Bảng 5.3. Bảng mã Network AI state v1
Mã | Nhãn hiển thị | Nguồn tạo kết luận
0 | Bình thường | Isolation Forest trả +1
1 | Nghi ngờ bất thường | Isolation Forest trả -1
2 | Mất gói | Quy tắc loss lớn hơn 0
3 | Mất kết nối | Quy tắc ping bằng 0 với dữ liệu mới
4 | Chờ dữ liệu | Thiếu mẫu hoặc ít giá trị RTT phân biệt
5 | Lỗi dữ liệu | Thiếu, cũ, lỗi hoặc đầu ra không hợp lệ

Thứ tự xử lý ưu tiên kiểm tra chất lượng, sau đó ping, loss và cuối cùng RTT học máy. Một router bị mất phản hồi ICMP không được đưa qua mô hình với RTT bằng 0 để kết luận bình thường. Tương tự, thiếu dữ liệu cần hiển thị là thiếu dữ liệu, không phải mạng khỏe hoặc mất kết nối chắc chắn.

Publisher dùng biểu thức chính quy để tách stdout theo khối R-HQ, R-BR1, R-BR2 và đọc các chỉ số. Giá trị mặc định là state=5. Chỉ khi nhận dạng được thông điệp cùng metrics hợp lệ, chương trình mới gửi RTT/loss và mã tương ứng. Nếu định dạng stdout thay đổi mà parser không đổi theo, dashboard có thể nhận trạng thái lỗi.

## 5.6. Thiết kế kiểm tra và khả năng mở rộng

Kiểm tra offline trong repository đã đối chiếu parser với 36 khối router của log T10 và 8 tình huống tổng hợp. Phạm vi đó kiểm tra cách diễn giải đầu ra, không thay thế các phép thử mất gói, API lỗi hay dữ liệu cũ trên lab. Một bước cải thiện phù hợp là thay stdout tự do bằng JSON có schema rõ ràng.

Đầu ra có cấu trúc nên mang theo tên router, trạng thái, lý do, RTT, loss, timestamp mẫu, timestamp phân tích và phiên bản mô hình. Khi publisher dừng hoàn toàn, nó không thể tự gửi state=5; cần cơ chế nodata từ Zabbix để nhận biết mất cập nhật. Bản hồ sơ hiện chưa xác nhận trigger này được triển khai.

Thành phần hiện tại thực hiện phát hiện và hiển thị. Nó không chẩn đoán nguyên nhân gốc, không điều khiển route và không tự sửa lỗi mạng. Khả năng tự chạy sau reboot là chức năng vận hành chương trình; phục hồi sau gây lỗi trong thử nghiệm là kết quả đường đo trở lại bình thường, không phải quyết định tự chữa của AI.

# CHƯƠNG 6. THỰC NGHIỆM, ĐÁNH GIÁ VÀ HƯỚNG PHÁT TRIỂN

## 6.1. Phương pháp và nguồn minh chứng

Phần thực nghiệm dựa vào kế hoạch T01–T15 và ba hồ sơ kết quả T10, T12, T15 ngày 10/11/2026. T10 có log gốc và CSV trích xuất. T12 có CSV chép từ ảnh cùng tài liệu diễn giải. T15 có tài liệu ghi lại ảnh thao tác; chưa có raw boot journal trong repository.

Các đồ thị trong chương này được dựng lại từ CSV đã lưu, không phải ảnh chụp dashboard. Trục thời gian dùng thời điểm xuất báo cáo theo giờ Việt Nam. CSV không chứa lastclock từng mẫu ICMP và không cung cấp đầy đủ mốc bắt đầu gây lỗi, nên không được sử dụng để tính độ trễ phát hiện chính xác.

## 6.2. Tổng hợp trạng thái kiểm thử

@table Bảng 6.1. Kết quả và phạm vi xác nhận của kế hoạch kiểm thử
ID | Nội dung | Trạng thái theo hồ sơ
T01 | OSPF bình thường | Có snapshot Full và tuyến; cần tái kiểm tra lab
T02 | ICMP ba router | Có kết quả trong hồ sơ và log T10
T03 | BR1–BR2 qua wg0 | Có tuyến; chưa đủ đo lưu lượng đầu cuối
T04 | Handshake WireGuard | Chưa có minh chứng
T05–T06 | Lỗi và phục hồi đường trực tiếp | Chưa có log thử nghiệm
T07 | Chính sách BR tới HQ | Chưa có ruleset và kiểm thử đầy đủ
T08 | QoS dưới tải cạnh tranh | Chưa có bộ số đo xác nhận
T09 | Đủ mẫu và có score | Đã quan sát; chưa đo cảnh báo nhầm
T10 | Tăng RTT BR1 | Đạt chức năng một lần thử
T11 | Mất gói một phần | Chưa có kết quả
T12 | Mất phản hồi ICMP BR1 | Đạt chức năng một lần thử
T13 | Dữ liệu cũ/API lỗi | Chưa kiểm thử trên lab
T14 | Gửi và hiển thị kết quả | Có log sender và hồ sơ dashboard
T15 | Tự chạy sau reboot | Đạt chức năng một lần reboot máy chủ

Một trạng thái chưa có minh chứng không đồng nghĩa hạng mục chắc chắn hỏng. Nó cho thấy chưa đủ căn cứ để nghiệm thu trong báo cáo. Bảng 6.1 giúp xác định rõ phần đã làm và phần còn cần kiểm tra bổ sung.

## 6.3. T10 — Phản ứng khi RTT BR1 tăng

### 6.3.1. Điều kiện và phạm vi tác động

Nguồn đo là SERVER-ZABBIX 10.10.10.100, đích là BR1 10.10.20.1. Theo hồ sơ trước thử, route đi qua gateway 10.10.10.1 trên ens3. Kịch bản hướng dẫn phân loại gói IPv4/ICMP tới BR1 và đưa vào netem delay 100 ms ở chiều egress của máy đo; lưu lượng không khớp đi qua nhánh fq_codel.

Bộ minh chứng không có đầy đủ ảnh từng lệnh tc khi áp dụng nên chưa đối chiếu byte toàn bộ cấu hình gây trễ. Tuy vậy, log gốc cho thấy RTT tăng, nhãn mô hình đổi và kết quả trở lại bình thường sau thử. Đây là tác động trên đường đo ICMP, không phải thử lỗi WireGuard hoặc chuyển tuyến OSPF.

### 6.3.2. Kết quả từ log gốc

@table Bảng 6.2. Các mốc tiêu biểu của BR1 trong T10, ngày 10/11/2026
Giờ Việt Nam | RTT (ms) | Ping/loss | Score | State
14:23:36 | 1.197 | 1 / 0% | +0.1118 | 0
14:24:39 | 107.667 | 1 / 0% | -0.3752 | 1
14:25:24 | 107.667 | 1 / 0% | -0.3752 | 1
14:26:26 | 107.667 | 1 / 0% | -0.3835 | 1
14:27:36 | 1.175 | 1 / 0% | +0.1174 | 0

@figure t10.png | Hình 6.1. RTT ba router và decision score BR1 dựng từ CSV T10

Trước gây trễ, BR1 có RTT 1,197 ms và score dương 0,1118. Trong đoạn tăng trễ, RTT đạt 107,667 ms, mô hình trả nhãn nghi ngờ với score âm. Sau phục hồi, RTT về 1,175 ms và score dương 0,1174. Ping vẫn bằng 1 và loss bằng 0 trong các dòng này, xác nhận kết quả đi qua nhánh học máy RTT.

Hai báo cáo lúc 14:24:39 và 14:25:24 có cùng RTT, score và số mẫu lịch sử. Chúng không được đếm là hai phép đo ICMP độc lập. Ba bản báo nghi ngờ trong đoạn tăng trễ vẫn thuộc cùng một lần gây lỗi, không phải ba lần thử lặp.

Log còn ghi lúc 14:32:36, BR1 có RTT 1,963 ms, score -0,0978 và BR2 có RTT 1,829 ms, score -0,1086, cùng state=1. Chưa có nhãn chuẩn cho các mẫu này nên chưa phân loại là phát hiện đúng hay báo động giả. Việc giữ lại các điểm đó trong Hình 6.1 phản ánh đầy đủ dữ liệu đã có.

### 6.3.3. Gửi kết quả và phục hồi

Tệp log có 12 báo cáo hoàn chỉnh từ 14:21:03 đến 14:33:40, tương ứng 36 khối router; mỗi batch gửi 10 giá trị thành công, không có giá trị lỗi. Số khối này mô tả đầu ra chương trình, không phải 36 thí nghiệm độc lập.

Hồ sơ ping sau thử ghi 5 gói gửi, 5 nhận, mất gói 0%, RTT trung bình 1,051 ms. Qdisc ens3 trở lại fq_codel. Kết quả xác nhận đường đo đã phục hồi ở thời điểm kiểm tra. Chưa có log riêng của rollback unit để kết luận tác động được gỡ bởi timer hay thao tác thủ công.

Kết luận T10 là đạt chức năng trong một tình huống tăng RTT có kiểm soát. Chưa có tập kiểm thử độc lập, dữ liệu nhãn đầy đủ hoặc nhiều lần lặp để suy rộng hiệu quả phát hiện.

## 6.4. T12 — Mất phản hồi ICMP BR1 và phục hồi

Kịch bản T12 tác động tại ens3 của SERVER-ZABBIX, lọc gói ICMP có đích 10.10.20.1 và drop ở egress. Tài liệu ghi bộ lọc đã đếm 7 gói, 686 byte bị drop; ping thử gửi 3 gói nhưng không nhận phản hồi. Điều này xác nhận phép đo đã bị gián đoạn tại nguồn đo, không đủ kết luận router BR1 tắt hay toàn bộ chi nhánh mất dịch vụ.

@figure t12.png | Hình 6.2. Chuỗi trạng thái BR1 của T12 từ CSV chép lại ảnh nhật ký

Trước thử, các báo cáo lúc 16:50:19 và 16:51:39 có state=0. Từ 16:52:44 đến 16:56:25, bốn lần xuất báo cáo ghi state=3 kèm thông điệp QUY TAC: MAT KET NOI. Từ 16:57:39, các dòng được ghi lại trở về state=0.

Đầu ra này do điều kiện ping=0 trong ai_check.py. Nó là kết quả của quy tắc ICMP, không phải khả năng học máy phát hiện sự cố. CSV T12 được chép từ ảnh; không có raw journal để kiểm tra toàn bộ trường dữ liệu hoặc suy ra số mẫu ICMP độc lập.

Tài liệu kiểm tra sau thử ghi ping nhận 3/3 gói, mất gói 0%, RTT trung bình 1,080 ms; qdisc còn fq_codel root và không còn clsact. Đã có căn cứ về gỡ bộ lọc và phục hồi đường đo. Chưa có timestamp gây lỗi chính xác, log rollback hoặc ảnh dashboard ở state=3 trong repo.

## 6.5. T15 — Tự vận hành sau reboot

Hồ sơ ghi SERVER-ZABBIX khởi động lúc 16:19:31 ngày 10/11/2026. Một lần chạy nhìn thấy trong nhật ký sau boot là 16:33:11, có trạng thái cho cả ba router và sender processed 10, failed 0. Dashboard có ba thẻ cập nhật lúc 16:48:58, sau thời điểm khởi động.

Kết quả xác nhận chương trình tiếp tục chạy và gửi dữ liệu sau một lần reboot máy chủ mà không yêu cầu nhập lại thông tin đăng nhập thủ công trong chuỗi kiểm tra. Chưa có toàn bộ boot journal nên không gọi 16:33:11 là lần chạy đầu tiên hoặc lấy chênh lệch với thời điểm boot làm độ trễ khởi động.

Phép thử này không bao gồm reboot các router, EVE-NG hoặc khôi phục từ bản sao lưu. Vì vậy, kết luận được giới hạn ở khả năng tự vận hành của cấu hình máy chủ đã thiết lập.

## 6.6. Đánh giá theo mục tiêu

Đồ án đã hình thành chuỗi tích hợp từ mạng nhiều cơ sở tới giám sát ICMP, xử lý dữ liệu, suy luận RTT và hiển thị kết quả. Snapshot cấu hình cung cấp căn cứ về quan hệ OSPF và tuyến giữa các LAN. Log T10 cung cấp dữ liệu trực tiếp về nhãn, RTT, điểm mô hình và kết quả gửi. T12 bổ sung kiểm tra nhánh quy tắc, T15 bổ sung kiểm tra vận hành sau reboot.

Tuy nhiên, mức độ chứng minh giữa các phần chưa đồng đều. OSPF có snapshot nhưng chưa có số đo failover; WireGuard có giao diện và tuyến nhưng thiếu handshake; hệ thống có dashboard nhưng chưa xác nhận cảnh báo chủ động và nodata. Các mục tiêu ban đầu về đánh giá precision/recall/F1, SNMP và so sánh phương pháp ngưỡng chưa có kết quả đủ căn cứ.

Đối với AI, dữ liệu hiện tại hỗ trợ kết luận phản ứng chức năng trước một mức tăng RTT lớn. Chưa thể kết luận mô hình tốt hơn ngưỡng cố định, có tỷ lệ báo động giả thấp hoặc đáp ứng yêu cầu triển khai thực tế. Tuyên bố như vậy cần thêm baseline có kiểm soát, nhãn độc lập và kiểm thử nhiều điều kiện.

## 6.7. Hạn chế và hướng phát triển

Ưu tiên trước mắt là xuất lịch sử ICMP có lastclock, lưu sự kiện gây lỗi với thời gian bắt đầu/kết thúc và gắn nhãn độc lập. Dữ liệu bình thường phải bao gồm nhiều trạng thái tải hợp lệ. Trong giai đoạn đánh giá cần cố định baseline và phiên bản mô hình, tránh thay đổi ngưỡng sau khi đã xem tập kiểm thử.

Tiếp theo, cần lặp T10 với nhiều mức trễ, thực hiện T11 mất gói một phần, T13 dữ liệu cũ/API lỗi và thử ngừng publisher để xác nhận nodata. Các nhánh quy tắc phải được tổng hợp riêng với kết quả học máy. Độ trễ phát hiện cần đo từ thời điểm gây lỗi đến lúc Zabbix có mẫu và lúc chương trình xuất kết luận.

Về mạng, cần bổ sung wg show đã che thông tin không cần thiết, phép đo lưu lượng BR1–BR2, T05–T06 và kiểm thử quyền truy cập từ đúng LAN. QoS chỉ nên được nghiệm thu sau khi có cấu hình hàng đợi và hai luồng cạnh tranh với số đo trước/sau.

Về phần mềm, hướng phát triển gồm JSON có schema, tài khoản dịch vụ tối thiểu quyền, mã lỗi tiến trình nhất quán và lưu phiên bản mô hình. Có thể bổ sung jitter, lưu lượng, CPU hoặc trạng thái tunnel làm đặc trưng sau khi đã bảo đảm chất lượng và đồng bộ dữ liệu.

## 6.8. Kết luận

Đồ án đã xây dựng mô hình HQ–BR1–BR2 trên EVE-NG, sử dụng Linux/FRRouting và tích hợp giám sát Zabbix với thử nghiệm Isolation Forest. Kết quả lưu trong repository xác nhận đường xử lý đọc dữ liệu, phân tích, gửi và hiển thị đã hoạt động; ba phép thử chức năng ghi nhận phản ứng tăng RTT, mất phản hồi ICMP và tự chạy sau reboot máy chủ.

Đóng góp thực tế của mô hình là một chuỗi tích hợp có thể kiểm tra bằng cấu hình và nhật ký, đồng thời phân biệt rõ lỗi thu thập, quy tắc ICMP và nhãn học máy. Việc đánh giá độ chính xác, tính sẵn sàng của đường dự phòng và hiệu quả bảo mật/QoS còn cần bổ sung minh chứng trước khi đưa ra kết luận nghiệm thu đầy đủ.

# TÀI LIỆU THAM KHẢO

[1] hippozee, “DoAn-EVE-NG,” repository mã nguồn, cấu hình và minh chứng thực nghiệm, snapshot 9956c6d36a9fa777e1caa2875a2956ea5c004146, hồ sơ đến 10/11/2026. [Online]. Available: https://github.com/hippozee/DoAn-EVE-NG.

[2] EVE-NG Ltd., “EVE-NG Documentation.” [Online]. Available: https://www.eve-ng.net/index.php/documentation/.

[3] J. Moy, “OSPF Version 2,” RFC 2328, Apr. 1998. doi: 10.17487/RFC2328. [Online]. Available: https://www.rfc-editor.org/rfc/rfc2328.

[4] FRRouting Project, “OSPFv2,” FRR 8.4 documentation. [Online]. Available: https://docs.frrouting.org/en/stable-8.4/ospfd.html.

[5] WireGuard, “Quick Start.” [Online]. Available: https://www.wireguard.com/quickstart/.

[6] Zabbix SIA, “Zabbix 7.0 Documentation.” [Online]. Available: https://www.zabbix.com/documentation/7.0/en/manual.

[7] Zabbix SIA, “history.get,” Zabbix 7.0 API. [Online]. Available: https://www.zabbix.com/documentation/7.0/en/manual/api/reference/history/get.

[8] F. T. Liu, K. M. Ting, and Z.-H. Zhou, “Isolation Forest,” in Proc. 8th IEEE Int. Conf. Data Mining, 2008, pp. 413–422. doi: 10.1109/ICDM.2008.17.

[9] Scikit-learn developers, “IsolationForest,” API reference. [Online]. Available: https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.IsolationForest.html.

[10] Zabbix SIA, “zabbix_sender,” Zabbix 7.0 manpages. [Online]. Available: https://www.zabbix.com/documentation/7.0/en/manpages/zabbix_sender.

[11] Chrony Project, “chronyc manual,” version 4.3. [Online]. Available: https://chrony-project.org/doc/4.3/chronyc.html.

# PHỤ LỤC A. ÁNH XẠ ITEM VÀ CẤU TRÚC DỮ LIỆU

## A.1. Item nguồn trong database của lab

@table Bảng A.1. Ánh xạ item ICMP theo hồ sơ ngày 09/11/2026
Host | Host ID | Địa chỉ | Ping ID | Loss ID | RTT ID
R-HQ | 10683 | 10.10.10.1 | 51181 | 51182 | 51183
R-BR1 | 10684 | 10.10.20.1 | 51175 | 51176 | 51177
R-BR2 | 10685 | 10.10.30.1 | 51178 | 51179 | 51180

Các ID chỉ đúng với database được ghi nhận. Khi dựng lại Zabbix hoặc import template, cần truy vấn host/item theo tên và key rồi cập nhật ánh xạ. Không suy địa chỉ máy trạm từ địa chỉ router.

## A.2. Item đầu ra

@table Bảng A.2. Các key đầu ra trên host Zabbix server
Key | Loại giá trị | Đơn vị/ý nghĩa
ai.report | Text | Báo cáo cho ba router
ai.state[HQ/BR1/BR2] | Numeric unsigned | Mã từ 0 đến 5
ai.rtt[HQ/BR1/BR2] | Numeric float | ms
ai.loss[HQ/BR1/BR2] | Numeric float | %

Ký hiệu HQ/BR1/BR2 trong Bảng A.2 biểu diễn ba key riêng, không phải một key chứa dấu gạch chéo. Script setup đặt kiểu Zabbix trapper, Allowed hosts là 127.0.0.1, history 7d và trends 30d cho các item số. Chưa có export cấu hình API để đối chiếu mọi thuộc tính với lab hiện tại.

## A.3. Ý nghĩa dữ liệu CSV T10

observations.csv chứa report_time_utc, process_id, router, ping, loss_percent, rtt_ms, history_samples, decision_score và state. Timestamp là thời điểm chương trình xuất báo cáo. Tệp có 36 dòng cho 12 lần báo cáo ba router và được trích từ stdout, không phải dữ liệu history.get gốc.

# PHỤ LỤC B. CẤU HÌNH VÀ LỆNH KIỂM TRA TIÊU BIỂU

## B.1. Trích cấu hình FRR của HQ

```text
interface ens3
 ip ospf area 0
 ip ospf passive
!
interface ens4
 ip ospf area 0
 ip ospf cost 10
 ip ospf network point-to-point
!
interface ens6
 ip ospf area 0
 ip ospf cost 10
 ip ospf network point-to-point
!
router ospf
 ospf router-id 10.255.0.1
```

Đoạn trên được rút gọn từ HQ_FRR.txt để minh họa phần OSPF. Nó không bao gồm cấu hình địa chỉ IP, Linux forwarding hoặc các dịch vụ khác và không phải bộ cấu hình hoàn chỉnh để chạy độc lập.

## B.2. Trích cấu hình wg0 trên BR2

```text
interface wg0
 ip ospf area 0
 ip ospf cost 5
 ip ospf dead-interval 8
 ip ospf hello-interval 2
 ip ospf network non-broadcast
!
router ospf
 ospf router-id 10.255.0.3
 neighbor 10.200.12.1 poll-interval 5
```

Đây là phần OSPF trên giao diện logic, không phải cấu hình khóa và peer WireGuard. Bộ cấu hình tunnel cần được xuất riêng, loại bỏ khóa riêng trước khi bổ sung vào hồ sơ.

## B.3. Kiểm tra không làm thay đổi cấu hình

```bash
ip -br a
ip route
vtysh -c 'show ip ospf neighbor'
vtysh -c 'show ip route'
wg show
systemctl cat network-ai-check.service
systemctl list-timers network-ai-check.timer --no-pager
journalctl -u network-ai-check.service -n 50 --no-pager
chronyc tracking
```

Khi đưa output vào báo cáo, chỉ giữ thông tin cần thiết và che thông tin đăng nhập. Với một phép thử mới, cần lưu tuyến, cấu hình trước thử, timestamp tác động, kết quả và xác nhận phục hồi. Không sử dụng nguyên tệp BR1.txt như script vì tệp có cả nhật ký terminal và ký tự điều khiển.

# PHỤ LỤC C. DANH MỤC MINH CHỨNG VÀ THÔNG TIN CẦN HOÀN THIỆN

## C.1. Nguồn dùng để viết báo cáo

@table Bảng C.1. Nguồn minh chứng trong repository
Nguồn | Nội dung sử dụng | Giới hạn
DoAn_HQ_BR1_BR2.unl | Node, bridge, image, RAM/CPU | Không chứa toàn bộ cấu hình bên trong VM
HQ_FRR.txt, BR2_FRR.txt, BR1.txt | Cấu hình OSPF | Snapshot; BR1 lẫn log
HQ_CHECK.txt, BR1_check.txt, BR2_CHECK.txt | Interface, neighbor, route | Không phải đo trực tiếp ngày viết
ai/source, ai/systemd | Logic phân tích, publisher, lịch chạy | Bản xuất từ VM
ai/backup_manifest.json | Đối chiếu toàn vẹn bản xuất | Không phải sao lưu toàn VM
.../test-RTT-BR1.log | Log gốc T10 | Không chứa mốc gây lỗi đầy đủ
.../observations.csv | Vẽ Hình 6.1, lập Bảng 6.2 | Trích từ báo cáo stdout
.../T12_states_transcribed.csv | Vẽ Hình 6.2 | Chép từ ảnh
 docs/tests/T15_REBOOT_2026-11-10.md | Kết quả sau reboot | Chưa có raw boot journal

Các đường dẫn rút gọn có tiền tố evidence/ai/2026-11-10/. Những hình được dựng lại trong báo cáo gồm sơ đồ logic, luồng dữ liệu và đồ thị từ CSV. Ảnh dashboard/terminal của T10, T12, T15 được mô tả trong tài liệu nguồn nhưng chưa có tệp ảnh tương ứng trong repo để chèn.

## C.2. Thông tin hành chính còn thiếu

Cần điền họ tên sinh viên, mã sinh viên, lớp, ngành, mã ngành, khoa, người hướng dẫn và ngày giao/nộp đồ án. Tên đề tài trên bìa sử dụng tên trong hai bản đề cương lưu ở DoAn_EVE; cần đối chiếu với tên đã được duyệt trước khi nộp. Đề cương ghi TS. Mai Văn Lập, nhưng bìa giữ ô xác nhận để tránh mặc định thông tin chưa được người dùng chốt.

Tờ nhiệm vụ, lời cam đoan và lời cảm ơn là nội dung dự thảo để sinh viên kiểm tra. Không tạo chữ ký, ngày phê duyệt hay xác nhận của Hội đồng. Trước khi in, cập nhật toàn bộ trường trong Word để tạo mục lục và danh mục hình/bảng, rà soát thông tin cá nhân và bổ sung ảnh gốc nếu có.
